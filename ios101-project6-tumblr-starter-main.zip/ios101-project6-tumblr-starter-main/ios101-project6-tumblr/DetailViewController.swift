//
//  DetailViewController.swift
//  ios101-project6-tumblr
//
//  Created by Gokkul Karthikeyan on 3/13/26.
//
import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var descriptionsLabel: UILabel!
    
    var imageURL:URL!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        myImageView.loadImage(from: imageURL)
    }
}
